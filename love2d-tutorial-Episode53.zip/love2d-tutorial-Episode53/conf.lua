
function love.conf(t)
    t.window.width = 640
    t.window.height = 360
    t.window.display = 3
    t.window.x = 150
    t.window.y = 690
end